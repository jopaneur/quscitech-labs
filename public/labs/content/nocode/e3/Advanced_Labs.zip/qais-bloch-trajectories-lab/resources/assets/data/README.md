Data artifacts live here.
