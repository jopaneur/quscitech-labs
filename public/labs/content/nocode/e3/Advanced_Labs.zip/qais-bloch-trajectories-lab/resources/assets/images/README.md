Generated plots live here.
