Lab-specific references/notes.
